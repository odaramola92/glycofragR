library(testthat)
library(glycofragR)

test_check("glycofragR")
